<?php
error_reporting(0);
include('model.php');
$obj=new dbconnection();
$obj->getconnection();
$obj->selectdatabase();
$obj->capture();	
?>
<!DOCTYPE html>
<html>
<head>
  <title>Assignment1</title>
  <meta class="viewport" name="viewport" content="width=device-width, initial-scale=1.0">
  <meta charset="utf-8">
  <link rel='stylesheet' href="css/bootstrap.min.css">
  <link rel='stylesheet' href="css/style.css">
  <link rel='stylesheet' href="css/responsive.css">
</head>
<body>


<div class="container">
<div class="row">
<div class="span3"></div>
<div class="span6" style="border-right: 1px solid #eee;">
<form class="form-custom" method="post">
                            
                                <div class="span3">
                                    <div class="form-group">
                                        <label for="exampleInputEmail3">Name</label>
                             <input class="form-control" name="name" id="exampleInputEmail3" required="" type="text">
                                    </div>
                                </div>
                                <div class="span3">
                                    <div class="form-group">
                                        <label for="exampleInputEmail3">Mobile Number</label>
                            <input class="form-control" name="mobile" id="exampleInputEmail3" required="" type="text">
                                    </div>
                                </div>
                           
                                <div class="span3">
                                    <div class="form-group">
                                        <label for="exampleInputEmail3">Email</label>
                              <input class="form-control" name="email" id="exampleInputEmail3" required="" type="email">
                                    </div>
                                </div>

                                 <div class="span3">
                                    <div class="form-group">
                                        <label for="exampleInputEmail3">Country</label>
                              <select name="country" class="form-control" required=""><option value=""></option>
							  <option value="india">India</option>
							  <option value="unitedstates">United States</option>
							  <option value="unitedkingdom">United Kingdom</option>
							  </select>
                                    </div>
                                </div>
							 
                                <div class="span3">
                                    <div class="form-group">
                                        <label for="exampleInputEmail33">Birthday</label>
                              <input class="form-control" name="birthday" id="exampleInputEmail33" required="" type="date">
                                    </div>
                                </div>

                                <div class="span3">
                                    <div class="form-group">
                                        <label for="exampleInputEmail34">About You</label>
                               <textarea class="form-control" name="aboutyou"  rows="2" cols="5"  id="exampleInputEmail34" required="" ></textarea>
							  
                                    </div>
                                </div>
							 
							 <div class="span3 text-right"> <input name="submit" id="capture" type="submit" class="btn btn-dark btn-rounded" value="Submit"> </div>
							 
							  
								
                                
                                


                            
                                
                           
                                
                            
                        </form>
						
</div>


<div class="span3"></div>
</div>
</div>						
						
						
						
</body>
</html>
