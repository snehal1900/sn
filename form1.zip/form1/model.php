<?php
class dbconnection
{   		private $server = "localhost";
			private $userName = "root";
			private $password = "root";
			private $database = "form1";
		
		
			public function getconnection()
			{
				$con = mysql_connect($this->server,$this->userName,$this->password); 
		
				if($con)
				{
					return $con;
						
				}
				else
				{
					return mysql_error().mysql_errno();
				}		
			}
			public function selectdatabase()
			{
				$con = $this->getConnection();  
				$dbResult = mysql_select_db($this->database,$con); 
					
				if($dbResult)
				{
					return true;
				}
				else
				{	
					return false;
				}		
			}
			public function capture()
			{
				
						  
				$name     =   $_POST['name'];
				$mobile       =   $_POST['mobile'];
				$email        =   $_POST['email'];
				$country  =   $_POST['country'];
				$birthday  =   $_POST['birthday'];
				$aboutyou  =   $_POST['aboutyou'];
						   
				$sql="INSERT INTO table1 (name,mobile,email,country,birthday,aboutyou) VALUES ('$name','$mobile','$email','$country','$birthday','$aboutyou')";
		   
				mysql_query($sql);	
			}

			   
}