<?php
error_reporting(0);
include('model.php');
$obj=new dbconnection();
$obj->getconnection();
$obj->selectdatabase();


$result = mysql_query("SELECT * FROM table1");
$num_rows = mysql_num_rows($result);
                
?>
<!DOCTYPE html>
<html>
<head>
  <title>Assignment1</title>
  <meta class="viewport" name="viewport" content="width=device-width, initial-scale=1.0">
  <meta charset="utf-8">
  <link rel='stylesheet' href="css/bootstrap.min.css">
  <link rel='stylesheet' href="css/style.css">
  <link rel='stylesheet' href="css/responsive.css">
</head>
<body>


<div class="container">
<div class="row">

<div class="span12" style="border-right: 1px solid #eee;">

                            <div class="row">
                                <div class="span2">
                                    <div class="form-group">
                                        <label for="exampleInputEmail3">Name</label>
                             
                                    </div>
                                </div>
                                <div class="span2">
                                    <div class="form-group">
                                        <label for="exampleInputEmail3">Mobile Number</label>
                            
                                    </div>
                                </div>
                           
                                <div class="span2">
                                    <div class="form-group">
                                        <label for="exampleInputEmail3">Email</label>
                              
                                    </div>
                                </div>

                                 <div class="span2">
                                    <div class="form-group">
                                        <label for="exampleInputEmail3">Country</label>
                              
                                    </div>
                                </div>
								 <div class="span2">
                                    <div class="form-group">
                                        <label for="exampleInputEmail3">Birthday</label>
                              
                                    </div>
                                </div>
								 <div class="span2">
                                    <div class="form-group">
                                        <label for="exampleInputEmail3">About You</label>
                              
                                    </div>
                                </div>
							 </div>	
							 <hr/>
							 <?php 
		    if ($num_rows != 0) 
            {
				while($row = mysql_fetch_array($result)) 
				{
?>
							<div class="row">
                                <div class="span2">
                                    <div class="form-group">
                                        <label for="exampleInputEmail3"><?php echo  $row["name"]; ?></label>
                             
                                    </div>
                                </div>
                                <div class="span2">
                                    <div class="form-group">
                                        <label for="exampleInputEmail3"><?php echo  $row["mobile"]; ?></label>
                            
                                    </div>
                                </div>
                           
                                <div class="span2">
                                    <div class="form-group">
                                        <label for="exampleInputEmail3"><?php echo  $row["email"]; ?></label>
                              
                                    </div>
                                </div>

                                 <div class="span2">
                                    <div class="form-group">
                                        <label for="exampleInputEmail3"><?php echo  $row["country"]; ?></label>
                              
                                    </div>
                                </div>
								 <div class="span2">
                                    <div class="form-group">
                                        <label for="exampleInputEmail3"><?php echo  $row["birthday"]; ?></label>
                              
                                    </div>
                                </div>
								 <div class="span2">
                                    <div class="form-group">
                                        <label for="exampleInputEmail3"><?php echo  $row["aboutyou"]; ?></label>
                              
                                    </div>
                                </div>
							 </div>	 
							 
							<?php   
				}
			}
			else
			{
				echo "No Details Available";
			}				
		?>  	
								
                                
                                


                            
                                
                           
                                
                            
                        
</div>


		
		
		
		
		
		
 	

</div>
</div>						
						
						
						
</body>
</html>