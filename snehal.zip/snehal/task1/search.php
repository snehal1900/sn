<?php  
 $connect = mysqli_connect("localhost", "root", "", "ts1");

 if(isset($_POST["query"]))  
 {  $connect = mysqli_connect("localhost", "root", "", "ts1");
      $output = '';  
      $query = "SELECT * FROM `ts` WHERE city_name LIKE '%".$_POST["query"]."%'";  
      $result = mysqli_query($connect, $query);  
      $output = '<ul class="list-unstyled">';  
      if(mysqli_num_rows($result) > 0)  
      {  
           while($row = mysqli_fetch_array($result))  
           {  
                $output .= '<li>'.$row["city_name"].'</li>';  
           } 
	   
      }  
      else  
      {  
           $output .= '<li>City Not Found</li>';  
      }  
	  
      $output .= '</ul>';  
      echo $output;  
 }  
 ?>  